# Cómo publicar tu nuevo portfolio

## Qué contiene `index.html`
Todo el diseño en un solo archivo: estilos, textos en español e inglés, modo claro y oscuro, la animación de los puntos, el deslizante de "Cómo pienso", el menú para móvil y el botón de volver arriba.

## Pasos en GitHub
1. Haz una copia de seguridad de tu `index.html` actual. Por ejemplo, renómbralo a `index-anterior.html`.
2. Sube el nuevo `index.html` a la raíz del repositorio, en el mismo sitio donde estaba el anterior.
3. Guarda los cambios con un *commit*. GitHub Pages tarda uno o dos minutos en actualizar la web.

## Archivos que usa (los que ya tienes en tu repo)
No hay que mover nada si mantienes las mismas rutas:

| Uso | Ruta |
|---|---|
| Tu foto (Sobre mí) | `FOTO4.jpg` |
| Imagen al compartir en redes | `assets/og-image.jpg` |
| Thunder Gym | `thunder-gym.png` |
| Hexalud Wellness | `assets/hexalud-hero.jpg` |
| WiseCook | `assets/wisecook-hero.jpg` |
| Velada | `assets/velada-hero.jpg` |
| Linkers | `assets/linkers-hero.jpg` |
| Chiltepiik | `assets/chiltepik-hero.jpg` |
| Habemus Pizza | `assets/habemus-pizza-hero.jpg` |
| Jaguares de Nayarit | `assets/jaguares-hero.jpg` |
| Holly Body | `assets/holly-body-hero.jpg` |
| EKA Active | `assets/eka-active-hero.jpg` |

Si alguna imagen no existe, la tarjeta muestra el degradado del color del proyecto en su lugar, sin icono roto.

Los enlaces a tus casos (`thunder-gym.html`, `hexalud-wellness.html`, `galeria.html`, etc.) son relativos, así que funcionan tal cual.

## Para cambiar cosas tú misma
- **Textos:** cada texto está en español dentro de la etiqueta. Su versión en inglés va en el atributo `data-en="..."` de la misma etiqueta. Cambia ambos.
- **Proyectos UX/UI:** búscalos en el `<script>`, dentro de `const projects = [...]`. Ahí están el nombre, la descripción, las herramientas, la imagen y el enlace de cada uno. Los 3 primeros de la lista son los que se ven al principio.
- **Proyectos gráficos:** en el HTML, bloque `<div class="mood">`. El orden de las piezas es el orden en que aparecen.
- **Colores:** al principio del `<style>`, en `:root`. Los nombres son `--teal` (turquesa), `--lilac` (lila) y `--pink` (rosa). El modo claro tiene sus propios valores justo debajo.
- **Nivel de idiomas:** en cada `<li style="--v:85%">`, cambia el porcentaje.

## Nota
`projects.json` ya no se usa en esta página, porque los proyectos están dentro de `index.html`. Puedes dejarlo en el repo sin problema.

---

# Casos de estudio y galería

## Archivos nuevos
- `thunder-gym.html`, `hexalud-wellness.html`, `wisecook.html`, `velada.html`, `linkers.html`
- `chiltepik.html`, `habemus-pizza.html`, `jaguares.html`, `eka-active.html`, `holly-body.html`
- `galeria.html`
- `assets/case.css` y `assets/case.js`: estilos y comportamiento compartidos por todos los casos. Súbelos a tu carpeta `assets/`.

Sustituyen a las páginas con el mismo nombre que ya tienes. Haz copia de seguridad antes.

## Imágenes
Cada caso usa las mismas rutas de imagen que tus páginas actuales (por ejemplo `assets/tg-splash.jpg` o `assets/hexalud-01.jpg`), así que no hay que mover nada.

**A revisar:** en WiseCook he supuesto que las pantallas están en `assets/` (`assets/wisecook-auth-01.jpg`, etc.). Si están en la raíz del repositorio, quita `assets/` de esas rutas en `wisecook.html`.

## Velada y Linkers
Estas dos páginas no existían en tu web (sus enlaces daban error). Ahora tienen la plantilla con tu descripción y un aviso de "caso completo en preparación". Cuando tengas el contenido, puedo completarlas.

## Editar textos de un caso
Igual que en la portada: el texto en español va dentro de la etiqueta y el inglés en `data-en="..."`.
